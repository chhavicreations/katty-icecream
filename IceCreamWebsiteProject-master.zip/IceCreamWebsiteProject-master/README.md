# IceCreamWebsiteProject
This website is designed using Django & Bootstrap framework and the code is written in Python Programming Language.

## Homepage
![](ReadmeImages/homepage.jpg)

## Menu
![](ReadmeImages/menu.jpg)

## About Us
![](ReadmeImages/about-us.jpg)

## Contact Us
![](ReadmeImages/contact-us.jpg)

## Admin
![](ReadmeImages/admin.jpg)
